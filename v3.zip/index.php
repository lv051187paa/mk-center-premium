<?php
require_once "core/init.php";

new App;
//$matches = [];
//
//$controller = $_GET['controller'];
//$action = $_GET['action'];
//
//$controller_name = ucfirst($controller)."Controller";
//$controller_path = "controllers/".$controller_name.".php";
//
//if(file_exists($controller_path)) {
//    require $controller_path;
//
//    $controller_instance = new $controller_name;
//
//    call_user_func_array([$controller_instance, $action], []);
//}
