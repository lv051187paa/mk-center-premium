<?php

$host     = 'localhost';
$db       = 'mk_center';
$user     = 'root';
$password = '';
